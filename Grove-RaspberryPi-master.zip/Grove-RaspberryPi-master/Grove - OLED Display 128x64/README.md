Use a 128x64 OLED Display (based on SSD1308 Driver) with your Raspberry Pi

Based on Wim Huiskamps mbed library: http://mbed.org/users/wim/code/SSD1308_128x64_I2C/

CAUTION!
Dont connect this Display to a 3.3V or 5V pin on your RPi.
Use a 3.3V VReg connected to 5V!
